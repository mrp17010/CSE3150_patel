#/ bin / bash
c++ -std=c++11 -Wall main.cpp ECProduct.cpp ECCustomer.cpp ECOrder.cpp ECInventoryManager.cpp ECProductFactory.cpp ECCustomerFactory.cpp ECPayment.cpp ECShoppingCart.cpp -o main.out