#include "ECCombatant.h"

ECCombatant::ECCombatant(const std::string &ID): ID(ID) {}
void ECCombatant::Attack(ECCombatant *target) const {};