//
//  ECFighter2.cpp
//  
//
//

#include <vector>
#include <iostream>

#include "ECFighter2.h"
#include "ECCombatant.h"

using namespace std;

//***********************************************************
// Brute - A fighter that gets stronger everytime it defeats an enemy


//***********************************************************
// Acrobat - A fighter that can dodge an attack every 4 turns