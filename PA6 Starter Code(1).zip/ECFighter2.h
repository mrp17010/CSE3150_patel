//
//  ECFighter2.h
//  
//

#ifndef ECFighter2_h
#define ECFighter2_h

#include "ECFighter.h"
class ECCombatant;

// Now define your new fighters here...

//***********************************************************
// Brute - A fighter that gets stronger everytime it defeats an enemy

// Create a constructor function for the class

// Create a declaration for all ECCombatant virtual functions:
//    IsDead()
//    TakeTurn()
//    ReceiveAttack()
//    Attack()


//***********************************************************
// Acrobat - A fighter that can dodge an attack every 4 turns

// Create a constructor function for the class

// Create a declaration for all ECCombatant virtual functions:
//    IsDead()
//    TakeTurn()
//    ReceiveAttack()
//    Attack()



#endif /* ECFighter2_h */
